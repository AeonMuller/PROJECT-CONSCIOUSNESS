"""A reproducible laboratory for persistent functional cognition."""

__version__ = "0.1.0"

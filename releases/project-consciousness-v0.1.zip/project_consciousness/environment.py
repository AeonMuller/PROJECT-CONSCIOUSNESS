"""Private delayed-cue world with a deliberately small public observation.

World randomness is supplied and checkpointed by the runtime. An episode's
target and distractors are drawn before any action in that episode, and choices
do not change the distribution or random draw count of subsequent episodes.
"""

import random

from .contracts import Config, LabError


_STATE_KEYS = {"episode", "step", "target", "distractors"}


def _validate_config(config: Config) -> None:
    if not isinstance(config, Config):
        raise LabError("INVALID_INPUT", "environment configuration must be Config")


def _validate_rng(rng: random.Random) -> None:
    if not isinstance(rng, random.Random):
        raise LabError("INVALID_INPUT", "world RNG must be random.Random")


def _validate_environment(env: dict, config: Config) -> None:
    _validate_config(config)
    if not isinstance(env, dict) or set(env) != _STATE_KEYS:
        raise LabError("INVALID_INPUT", "environment must contain exactly episode, step, target, distractors")
    if type(env["episode"]) is not int or env["episode"] < 0:
        raise LabError("INVALID_INPUT", "episode must be a nonnegative integer")
    if type(env["step"]) is not int or not 0 <= env["step"] <= config.delay + 1:
        raise LabError("INVALID_INPUT", "step is outside the configured episode")
    if type(env["target"]) is not int or env["target"] not in (0, 1):
        raise LabError("INVALID_INPUT", "target must be integer 0 or 1")
    distractors = env["distractors"]
    if (
        type(distractors) is not list
        or len(distractors) != config.delay
        or any(type(value) is not int or value not in (0, 1) for value in distractors)
    ):
        raise LabError("INVALID_INPUT", "distractors must be a delay-length list of binary integers")


def _new_episode(episode: int, config: Config, rng: random.Random) -> dict:
    return {
        "episode": episode,
        "step": 0,
        "target": rng.randrange(2),
        "distractors": [rng.randrange(2) for _ in range(config.delay)],
    }


def initial_environment(config: Config, rng: random.Random) -> dict:
    """Create episode zero, sampling all of its hidden contents immediately."""
    _validate_config(config)
    _validate_rng(rng)
    return _new_episode(0, config, rng)


def observe(env: dict, config: Config) -> dict:
    """Return only the current cue/distractor, or no value at the choice."""
    _validate_environment(env, config)
    step = env["step"]
    if step == 0:
        phase, value = "cue", env["target"]
    elif step <= config.delay:
        phase, value = "distractor", env["distractors"][step - 1]
    else:
        phase, value = "choice", None
    return {"episode": env["episode"], "phase": phase, "value": value}


def transition(env: dict, action: str, config: Config, rng: random.Random) -> tuple[dict, dict]:
    """Apply one legal action without mutating the supplied environment.

    A terminal choice reports the completed episode and immediately prepares
    the next episode. The private next state never appears in the outcome.
    """
    _validate_environment(env, config)
    _validate_rng(rng)
    choice = env["step"] == config.delay + 1
    legal = ("left", "right") if choice else ("wait",)
    if type(action) is not str or action not in legal:
        raise LabError("INVALID_ACTION", "choice requires left/right; earlier phases require wait")

    if not choice:
        next_env = {**env, "step": env["step"] + 1, "distractors": list(env["distractors"])}
        return next_env, {"terminal": False, "success": None, "reward": 0.0, "episode": env["episode"]}

    success = (0 if action == "left" else 1) == env["target"]
    outcome = {"terminal": True, "success": success, "reward": 1.0 if success else 0.0, "episode": env["episode"]}
    return _new_episode(env["episode"] + 1, config, rng), outcome

"""Shared validated configuration and canonical, portable serialization."""

from dataclasses import asdict, dataclass
import hashlib
import json
import random
from typing import Any


class LabError(ValueError):
    """A machine-readable error at a laboratory boundary."""

    def __init__(self, code: str, message: str):
        super().__init__(message)
        self.code = code


def canonical(value: Any) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False)


def digest(value: Any) -> str:
    return hashlib.sha256(canonical(value).encode("utf-8")).hexdigest()


def clone(value: Any) -> Any:
    return json.loads(canonical(value))


def restore_rng(state: list | tuple) -> random.Random:
    def tuples(value):
        return tuple(tuples(item) for item in value) if isinstance(value, (tuple, list)) else value

    rng = random.Random()
    rng.setstate(tuples(state))
    return rng


def seeded_rng(seed: int, stream: str) -> random.Random:
    return random.Random(int(digest({"seed": seed, "stream": stream}), 16))


@dataclass(frozen=True)
class Config:
    delay: int = 3
    capacity: int = 64
    agent_mode: str = "episodic"
    read_mode: str = "intact"
    write_enabled: bool = True

    def __post_init__(self):
        if type(self.delay) is not int or not 1 <= self.delay <= 100:
            raise LabError("INVALID_INPUT", "delay must be an integer from 1 to 100")
        if type(self.capacity) is not int or not 1 <= self.capacity <= 4096:
            raise LabError("INVALID_INPUT", "capacity must be an integer from 1 to 4096")
        if not isinstance(self.agent_mode, str) or self.agent_mode not in {"episodic", "history", "reactive"}:
            raise LabError("INVALID_INPUT", "unknown agent_mode")
        if not isinstance(self.read_mode, str) or self.read_mode not in {"intact", "sham", "block_all", "mask_relevant", "mask_irrelevant"}:
            raise LabError("INVALID_INPUT", "unknown read_mode")
        if type(self.write_enabled) is not bool:
            raise LabError("INVALID_INPUT", "write_enabled must be boolean")

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict) -> "Config":
        if not isinstance(data, dict):
            raise LabError("INVALID_INPUT", "configuration must be an object")
        try:
            return cls(**data)
        except TypeError as error:
            raise LabError("INVALID_INPUT", str(error)) from error

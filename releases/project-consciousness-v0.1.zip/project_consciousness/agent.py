"""A causal-memory policy over a public observation, with no hidden cue cache."""

from .contracts import Config, LabError, clone
from .memory import (
    AGENT_ID, append_record, memory_bytes, observation_record, retrieve_episodic,
    retrieve_history, validate_observation, validate_records, validate_tick,
)


def initial_agent() -> dict:
    return {"records": []}


def _copy_state(state: dict, tick: int) -> dict:
    if not isinstance(state, dict) or set(state) != {"records"}:
        raise LabError("INVALID_INPUT", "agent state must contain records only")
    validate_records(state["records"], tick)
    return clone(state)


def _choose(phase: str, cues: list, rng) -> tuple[str, float | None, float | None]:
    """No intervention label, private world or configuration reaches policy."""
    if phase != "choice":
        return "wait", None, None
    if cues:
        probability_left = 1.0 if cues[0]["value"] == 0 else 0.0
        return ("left" if probability_left == 1.0 else "right"), probability_left, 1.0
    return ("left" if rng.random() < 0.5 else "right"), 0.5, 0.5


def advance_agent(state: dict, observation: dict, tick: int, config: Config, rng) -> tuple[dict, dict]:
    validate_tick(tick)
    validate_observation(observation)
    next_state = _copy_state(state, tick)
    encoded_ids = []
    if config.write_enabled and config.agent_mode != "reactive" and observation["phase"] != "choice":
        record = observation_record(observation, tick)
        next_state["records"], added = append_record(next_state["records"], record, config.capacity, tick)
        if added:
            encoded_ids.append(record["record_id"])
    cues, scanned = [], 0
    if observation["phase"] == "choice" and config.agent_mode != "reactive":
        reader = retrieve_history if config.agent_mode == "history" else retrieve_episodic
        cues, scanned = reader(next_state["records"], observation["episode"], tick, config.read_mode)
    action, probability_left, confidence = _choose(observation["phase"], cues, rng)
    decision = {
        "action": action, "probability_left": probability_left, "confidence": confidence,
        "memory_ids": [record["record_id"] for record in cues], "encoded_ids": encoded_ids,
        "records_scanned": scanned, "memory_bytes": memory_bytes(next_state["records"]),
    }
    return next_state, decision


def record_result(state: dict, observation: dict, decision: dict, outcome: dict, tick: int, config: Config) -> dict:
    validate_tick(tick)
    validate_observation(observation)
    next_state = _copy_state(state, tick)
    if not config.write_enabled or config.agent_mode == "reactive":
        return next_state
    if (not isinstance(decision, dict) or not isinstance(decision.get("action"), str)
            or decision["action"] not in {"wait", "left", "right"}):
        raise LabError("INVALID_INPUT", "invalid action result linkage")
    if not isinstance(outcome, dict):
        raise LabError("INVALID_INPUT", "outcome must be an object")
    if "episode" in outcome and outcome["episode"] != observation["episode"]:
        raise LabError("INVALID_INPUT", "outcome belongs to another episode")
    if (observation["phase"] == "choice") == (decision["action"] == "wait"):
        raise LabError("INVALID_INPUT", "action is incompatible with observation phase")
    record = {
        "record_id": f"action:{tick}", "episode": observation["episode"], "tick": tick,
        "kind": "outcome", "value": None, "source_kind": "OBSERVED",
        "origin_agent_id": AGENT_ID, "source_id": f"action:{tick}",
        "action": decision["action"], "result": outcome,
    }
    next_state["records"], _ = append_record(next_state["records"], record, config.capacity, tick)
    return next_state
